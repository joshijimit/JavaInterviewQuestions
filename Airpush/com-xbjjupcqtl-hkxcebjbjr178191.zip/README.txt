Welcome to the Airpush SDK for Android!

Included in this distribution is everything you need to integrate Airpush ads into your Android applications. Get started by reading the Bundled SDK installation guide at http://manage.airpush.com/docs/index.php?title=Bundle_SDK_1.0_Documentation

You can download the demo project "Bundle demo" using the following link http://manage.airpush.com/sdk/BundleDemo.zip. This demo provides an overview on how to integrate the Airpush Bundled SDK into your app. If you have any issues integrating SDK, please feel free to email publishersupport@airpush.com and our support team will get them resolved ASAP.
